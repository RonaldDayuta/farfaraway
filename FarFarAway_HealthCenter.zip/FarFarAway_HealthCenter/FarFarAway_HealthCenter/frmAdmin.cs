﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FarFarAway_HealthCenter
{
    public partial class frmAdmin : Form
    {
        public frmAdmin()
        {
            InitializeComponent();
            ucCA.Visible = false;
            ucMA.Visible = false;

            ucCA.BackColor = Color.Transparent;
            ucMA.BackColor = Color.Transparent;
            pnlMain.BackColor = Color.Transparent;
        }

        private void btnMAChangeColorA(object sender, EventArgs e)
        {
            btnMA.ForeColor = Color.Gray;
            btnMA.BackColor = Color.White;
        }

        private void btnMAChangeColorB(object sender, EventArgs e)
        {
            btnMA.ForeColor = Color.White;
            btnMA.BackColor = Color.Gray;
        }

        private void btnCAChangeColorA(object sender, EventArgs e)
        {
            btnCA.ForeColor = Color.Gray;
            btnCA.BackColor = Color.White;
        }

        private void btnCAChangeColorB(object sender, EventArgs e)
        {
            btnCA.ForeColor = Color.White;
            btnCA.BackColor = Color.Gray;
        }

        private void btnLogChangeColorA(object sender, EventArgs e)
        {
            //btnLog.ForeColor = Color.Gray;
            //btnLog.BackColor = Color.White;
        }

        private void btnLogChangeColorB(object sender, EventArgs e)
        {
            //btnLog.ForeColor = Color.White;
            //btnLog.BackColor = Color.Gray;
        }

        private void btnLogoutChangeColorA(object sender, EventArgs e)
        {

            btnLogout.ForeColor = Color.Gray;
            btnLogout.BackColor = Color.White;
        }

        private void btnLogoutChangeColorB(object sender, EventArgs e)
        {
            btnLogout.ForeColor = Color.White;
            btnLogout.BackColor = Color.Gray;
        }

        private void btnLogout_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnMA_Click(object sender, EventArgs e)
        {
            ucMA.Visible = true;
            ucMA.BringToFront();
        }

        private void btnCA_Click(object sender, EventArgs e)
        {
            ucCA.Visible = true;
            ucCA.BringToFront();
        }
    }
}

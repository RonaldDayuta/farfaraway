﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FarFarAway_HealthCenter
{
    public partial class frmAssistant : Form
    {
        public frmAssistant()
        {
            InitializeComponent();
            ucCMR1.Visible = false;
            ucMMR1.Visible = false;
            

        }

        private void btnLogout_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnMMR_MouseEnter(object sender, EventArgs e)
        {
            btnMMR.ForeColor = Color.Gray;
            btnMMR.BackColor = Color.White;
        }

        private void btnMMR_MouseLeave(object sender, EventArgs e)
        {
            btnMMR.ForeColor = Color.White;
            btnMMR.BackColor = Color.Gray;
        }

        private void btnCMA_MouseEnter(object sender, EventArgs e)
        {
            btnCMA.ForeColor = Color.Gray;
            btnCMA.BackColor = Color.White;
        }

        private void btnCMA_MouseLeave(object sender, EventArgs e)
        {
            btnCMA.ForeColor = Color.White;
            btnCMA.BackColor = Color.Gray;
        }

        private void btnLogout_MouseEnter(object sender, EventArgs e)
        {
            btnLogout.ForeColor = Color.Gray;
            btnLogout.BackColor = Color.White;
        }

        private void btnLogout_MouseLeave(object sender, EventArgs e)
        {
            btnLogout.ForeColor = Color.White;
            btnLogout.BackColor = Color.Gray;
        }

        private void btnCMA_Click(object sender, EventArgs e)
        {
            ucCMR1.Visible = true;
            ucCMR1.BringToFront();
        }

        private void btnMMR_Click(object sender, EventArgs e)
        {
            ucMMR1.Visible = true;
            ucMMR1.BringToFront();
        }
    }
}

﻿using FarFarAway_HealthCenter.UserControls;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FarFarAway_HealthCenter
{
    public partial class frmStaff : Form
    {
        public frmStaff()
        {
            InitializeComponent();
            
            ucCPA1.Visible = false;
            ucMPA1.Visible = false;
            ucMR1.Visible = false;
            


        }

        private void btnLogout_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnMR_MouseEnter(object sender, EventArgs e)
        {
            btnMR.ForeColor = Color.Gray;
            btnMR.BackColor = Color.White;
        }

        private void btnMR_MouseLeave(object sender, EventArgs e)
        {
            btnMR.ForeColor = Color.White;
            btnMR.BackColor = Color.Gray;
        }

        private void btnMPA_MouseEnter(object sender, EventArgs e)
        {
            btnMPA.ForeColor = Color.Gray;
            btnMPA.BackColor = Color.White;
        }

        private void btnMPA_MouseLeave(object sender, EventArgs e)
        {
            btnMPA.ForeColor = Color.White;
            btnMPA.BackColor = Color.Gray;

        }

        private void btnCPA_MouseEnter(object sender, EventArgs e)
        {
            btnCPA.ForeColor = Color.Gray;
            btnCPA.BackColor = Color.White;
        }

        private void btnCPA_MouseLeave(object sender, EventArgs e)
        {
            btnCPA.ForeColor = Color.White;
            btnCPA.BackColor = Color.Gray;
        }

        private void btnLogout_MouseEnter(object sender, EventArgs e)
        {
            btnLogout.ForeColor = Color.Gray;
            btnLogout.BackColor = Color.White;
        }

        private void btnLogout_MouseLeave(object sender, EventArgs e)
        {
            btnLogout.ForeColor = Color.White;
            btnLogout.BackColor = Color.Gray;
        }

        private void btnCPA_Click(object sender, EventArgs e)
        {
            ucCPA1.Visible = true;
            ucCPA1.BringToFront();
        }

        private void btnMR_Click(object sender, EventArgs e)
        {
            ucMR1.Visible = true;
            ucMR1.BringToFront();
        }

        private void btnMPA_Click(object sender, EventArgs e)
        {
            ucMPA1.Visible = true;
            ucMPA1.BringToFront();
        }
    }
}

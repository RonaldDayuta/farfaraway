﻿namespace FarFarAway_HealthCenter
{
    internal class btnCAChangeColorA
    {
    }
}
﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace FarFarAway_HealthCenter
{
    public partial class frmLogin : Form
    {
        MySqlDataReader dtr;
        public frmLogin()
        {
            InitializeComponent();
            pnlMain.BackColor = Color.Transparent;
        }
        private void btnExitChangeColorA(object sender, EventArgs e)
        {
            btnExit.BackColor = Color.Red;
            btnExit.ForeColor = Color.White;
        }

        private void btnExitChangeColorB(object sender, EventArgs e)
        {
            btnExit.BackColor = Color.Gray;
            btnExit.ForeColor = Color.Black;
        }

        private void btnMinChangeColorA(object sender, EventArgs e)
        {
            btnMin.BackColor = Color.Blue;
            btnMin.ForeColor = Color.White;
        }

        private void btnMinChangeColorB(object sender, EventArgs e)
        {
            btnMin.BackColor = Color.Gray;
            btnMin.ForeColor = Color.Black;
        }
        private void btnChangeColorA(object sender, EventArgs e)
        {
            btnLogin.ForeColor = Color.Gray;
            btnLogin.BackColor = Color.White;
        }

        private void btnChangeColorB(object sender, EventArgs e)
        {
            btnLogin.ForeColor = Color.White;
            btnLogin.BackColor = Color.Gray;
        }

        private void btnMin_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Login_Click(object sender, EventArgs e)
        {
            string cs = @"server=localhost; userid=root; password=; database=dbhealth_center";
            var con = new MySqlConnection(cs);

            try
            {
                con.Open();
                string stm = "select UserName, Password, Position from tbllogin WHERE UserName = @Name AND Password = @password";
                var cmd = new MySqlCommand(stm, con);

                cmd.Parameters.AddWithValue(@"Name", txtUsername.Text);
                cmd.Parameters.AddWithValue(@"password", txtPassword.Text);
                dtr = cmd.ExecuteReader();

                if (dtr.Read())
                {
                    string Cposition = "";

                    Cposition = dtr.GetString("Position");

                    if(Cposition == "Admin")    
                    {
                        frmAdmin fAdmin = new frmAdmin();
                        fAdmin.TopLevel = false;
                        pnlMain.Controls.Add(fAdmin);
                        fAdmin.BringToFront();
                        fAdmin.Show();
                    }
                    else if (Cposition == "Assistant")
                    {
                        //
                        frmAssistant fAssistant = new frmAssistant();
                        fAssistant.TopLevel = false;
                        pnlMain.Controls.Add(fAssistant);
                        fAssistant.BringToFront();
                        fAssistant.Show();
                    }
                    else if (Cposition == "Staff")
                        //receptionist
                    {
                        frmStaff fStaff = new frmStaff();
                        fStaff.TopLevel = false;
                        pnlMain.Controls.Add(fStaff);
                        fStaff.BringToFront();
                        fStaff.Show();
                    }
                    
                }
                else
                {
                    MessageBox.Show("Please Input Username or Password First");
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            

            txtUsername.Text = "";
            txtPassword.Text = "";  
        }
    }
}

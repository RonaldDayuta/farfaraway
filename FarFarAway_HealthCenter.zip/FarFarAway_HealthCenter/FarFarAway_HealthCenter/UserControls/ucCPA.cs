﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FarFarAway_HealthCenter.UserControls
{
    public partial class ucCPA : UserControl
    {
        MySqlDataReader dtr;

        public ucCPA()
        {
            InitializeComponent();
        }

        private void txtTextOnly_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsLetter(e.KeyChar) && !char.IsControl(e.KeyChar))
            {
                e.Handled = true;
                string message = "Please Enter Letters Only!";
                string title = "Notice";
                MessageBoxButtons buttons = MessageBoxButtons.OK;
                MessageBoxIcon icon = MessageBoxIcon.Warning;
                MessageBox.Show(message, title, buttons, icon);
            }
        }

        private void txtNumbersOnly_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsNumber(e.KeyChar) && !char.IsControl(e.KeyChar))
            {
                e.Handled = true;
                string message = "Please Enter Numbers Only";
                string title = "Notice";
                MessageBoxButtons buttons = MessageBoxButtons.OK;
                MessageBoxIcon icon = MessageBoxIcon.Warning;
                MessageBox.Show(message, title, buttons, icon);
            }
        }

        private void btnCreateAccount_Click(object sender, EventArgs e)
        {
            int Na = 0;

            string ca = @"server=localhost; userid=root; password=; database=dbhealth_center";
            var con = new MySqlConnection(ca);
            string gender = "";

            if (rbMale.Checked)
            {
                gender = "Male";
            }
            else if (rbFemale.Checked)
            {
                gender = "Female";
            }

            try
            {
                con.Open();
                string stm = "INSERT INTO tblpatient (PID, LName, FName, MName, BDate, Address, Gender, Nationality, ContactNumber, Age, CivilStatus, BloodType)"
                    + "VALUES                       ("
                    + Na +                          ",'" 
                    + txtLastName.Text +            "','" 
                    + txtFirstName.Text +           "','" 
                    + txtInitial.Text +             "','" 
                    + this.dtpDOB.Text +            "','" 
                    + txtAddress.Text +             "','" 
                    + gender +                      "','" 
                    + txtNationality.Text +         "','" 
                    + txtContactNo.Text +           "'," 
                    + nudAge.Value +                ",'" 
                    + cboCivilStatus.SelectedItem + "','" 
                    + txtBloodType.Text +           "')";


                var cmd = new MySqlCommand(stm, con);
                dtr = cmd.ExecuteReader();

                MessageBox.Show("Successfully Added to database");

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            con.Close();

            txtLastName.Clear();
            txtFirstName.Clear();
            txtInitial.Clear();
            txtAddress.Clear();
            rbMale.Checked = false;
            rbFemale.Checked = false;
            dtpDOB.Value = new DateTime(1950, 01, 01);
            txtNationality.Clear();
            txtContactNo.Clear();
            nudAge.Value = 0;
            cboCivilStatus.Text = " ";
            txtBloodType.Clear();


        }

        private void txtAddress_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtSpecialCharacter_KeyPress(object sender, KeyPressEventArgs e)
        {
           
        }
    }
}

﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace FarFarAway_HealthCenter.UserControls
{
    public partial class ucMMR : UserControl
    {
        MySqlConnection con = new MySqlConnection("datasource = localhost; userid = root; password = ; database = dbhealth_center; Convert Zero Datetime=True;");
        MySqlCommand cmd = new MySqlCommand();
        MySqlDataReader dtr;
        MySqlDataAdapter adapter;
        DataTable tbl;

        public ucMMR()
        {
            InitializeComponent();
        }
        public void loadData()
        {
            try
            {
                con.Open();

                string sql = "SELECT * FROM tblmedrecord";
                cmd = new MySqlCommand(sql, con);
                dtr = cmd.ExecuteReader();
                DataTable dt = new DataTable();
                dt.Load(dtr);
                dgvMMR.DataSource = dt;

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                con.Close();
            }
        }

        private void ucMMR_Load(object sender, EventArgs e)
        {
            loadData();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            int index;
            index = e.RowIndex;
            DataGridViewRow row = dgvMMR.Rows[index];
            lblRID.Text             = row.Cells[0].Value.ToString();
            txtPatientID.Text       = row.Cells[1].Value.ToString();
            txtHeight.Text          = row.Cells[2].Value.ToString();
            txtWeight.Text          = row.Cells[3].Value.ToString();
            txtBloodPressure.Text   = row.Cells[4].Value.ToString();
            txtPulseRate.Text       = row.Cells[5].Value.ToString();
            txtSugarLevel.Text      = row.Cells[6].Value.ToString();
            txtTemperature.Text     = row.Cells[7].Value.ToString();
            txtDescription.Text     = row.Cells[8].Value.ToString();
            txtSymptoms.Text        = row.Cells[9].Value.ToString();
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            con.Open();
            MySqlCommand cmd = new MySqlCommand("Update tblmedrecord set PID =@PID, Height =@Height, Weight =@Weight, BloodPressure =@BloodPressure, PulseRate =@PulseRate, SugarLevel =@SugarLevel, Temperature =@Temperature, Description =@Description, Symptoms =@Symptoms where MRID =@MRID", con);
            cmd.Parameters.AddWithValue("@MRID", int.Parse(lblRID.Text));
            cmd.Parameters.AddWithValue("@PID", txtPatientID.Text);
            cmd.Parameters.AddWithValue("@Height", txtHeight.Text);
            cmd.Parameters.AddWithValue("@Weight", txtWeight.Text);
            cmd.Parameters.AddWithValue("@BloodPressure", txtBloodPressure.Text);
            cmd.Parameters.AddWithValue("@PulseRate", txtPulseRate.Text);
            cmd.Parameters.AddWithValue("@SugarLevel", txtSugarLevel.Text);
            cmd.Parameters.AddWithValue("@Temperature", txtTemperature.Text);
            cmd.Parameters.AddWithValue("@Description", txtDescription.Text);
            cmd.Parameters.AddWithValue("@Symptoms", txtSymptoms.Text);

            cmd.ExecuteNonQuery();


            con.Close();
            MessageBox.Show("Updated Successfully");

            loadData();
            loadData();
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            loadData();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            int MRID = Int32.Parse(lblRID.Text);
            con.Open();
            MySqlCommand cmd = new MySqlCommand("Delete from tblmedrecord where MRID =@MRID", con);
            cmd.Parameters.AddWithValue("@MRID", MRID);
            cmd.ExecuteNonQuery();
            con.Close();

            txtBloodPressure.Clear();
            txtDescription.Clear();
            txtHeight.Clear();
            txtPatientID.Clear();
            txtPulseRate.Clear();
            txtSugarLevel.Clear();
            txtSymptoms.Clear();
            txtTemperature.Clear();
            txtWeight.Clear();
            lblRID.Text = "";

            MessageBox.Show("Deleted Successfully");
            loadData();
            loadData();
        }

        public void searchData(string valueToSearch)
        {
            string query = "Select * FROM tblmedrecord WHERE CONCAT (MRID) like '%" + valueToSearch + "%'";
            cmd = new MySqlCommand(query, con);
            adapter = new MySqlDataAdapter(cmd);
            tbl = new DataTable();
            adapter.Fill(tbl);
            dgvMMR.DataSource = tbl;
        }

        private void EventSearchKey(object sender, EventArgs e)
        {
            string valueToSearch = txtSearchMRID.Text.ToString();
            searchData(valueToSearch);
        }

        private void txtNumbersOnly_KeyPress(object sender, KeyPressEventArgs e)
        {

            if (!char.IsNumber(e.KeyChar) && !char.IsControl(e.KeyChar))
            {
                e.Handled = true;
                string message = "Please Enter Numbers Only";
                string title = "Notice";
                MessageBoxButtons buttons = MessageBoxButtons.OK;
                MessageBoxIcon icon = MessageBoxIcon.Warning;
                MessageBox.Show(message, title, buttons, icon);
            }
        }
    }
}

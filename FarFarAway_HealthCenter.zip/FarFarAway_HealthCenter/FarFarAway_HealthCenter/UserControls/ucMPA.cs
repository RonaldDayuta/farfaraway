﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FarFarAway_HealthCenter.UserControls
{

    public partial class ucMPA : UserControl
    {
        MySqlConnection con = new MySqlConnection("datasource = localhost; userid = root; password = ; database = dbhealth_center; Convert Zero Datetime=True;");
        MySqlCommand cmd = new MySqlCommand();
        MySqlDataReader dtr;
        MySqlDataAdapter adapter;
        DataTable tbl;



        public ucMPA()
        {
            InitializeComponent();
        }

        public void loadData()
        {
            try
            {
                con.Open();

                string sql = "SELECT * FROM tblpatient";
                cmd = new MySqlCommand(sql, con);
                dtr = cmd.ExecuteReader();
                DataTable dt = new DataTable();
                dt.Load(dtr);
                dgvMPA.DataSource = dt;

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                con.Close();
            }
        }
        private void ucMPA_Load(object sender, EventArgs e)
        {
            loadData();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {

            int ID = Int32.Parse(lblPID.Text);
            con.Open();
            MySqlCommand cmd = new MySqlCommand("Delete from tblpatient where PID =@PID", con);
            cmd.Parameters.AddWithValue("@PID", ID);
            cmd.ExecuteNonQuery();
            con.Close();

            lblPID.Text = "";
            txtAddress.Clear();
            txtBloodType.Clear();
            txtContactNo.Clear();
            txtFirstName.Clear();
            txtLastName.Clear();
            txtMiddleInitial.Clear();
            txtNationality.Clear();
            txtSearchID.Clear();
            dtpDOB.Value = new DateTime(1950, 01, 01);
            nudAge.Value = 0;
            cboCivilStatus.Text = " ";
            rbMale.Checked = false;
            rbFemale.Checked = false;

            MessageBox.Show("Deleted Successfully");

            loadData();
            loadData();
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            string cgender = "";

            if (rbMale.Checked)
            {
                cgender = "Male";
            }
            else if (rbFemale.Checked)
            {
                cgender = "Female";
            }

            con.Open();
            MySqlCommand cmd = new MySqlCommand("Update tblpatient set LName =@LName, FName =@FName, MName =@MName, BDate =@BDate, Address =@Address, Gender =@Gender, Nationality =@Nationality, ContactNumber =@ContactNumber, Age =@Age, CivilStatus =@CivilStatus, BloodType =@BloodType  where PID =@PID", con);

            cmd.Parameters.AddWithValue("@PID", int.Parse(lblPID.Text));
            cmd.Parameters.AddWithValue("@LName", txtLastName.Text);
            cmd.Parameters.AddWithValue("@FName", txtFirstName.Text);
            cmd.Parameters.AddWithValue("@MName", txtMiddleInitial.Text);
            cmd.Parameters.AddWithValue("@BDate", this.dtpDOB.Text);
            //cmd.Parameters.AddWithValue("@DateOfBirth", dtpDOB.Value.ToString("yyyyMMdd"));
            cmd.Parameters.AddWithValue("@Address", txtAddress.Text);
            cmd.Parameters.AddWithValue("@Gender", cgender);
            cmd.Parameters.AddWithValue("@Nationality", txtNationality.Text);
            cmd.Parameters.AddWithValue("@ContactNumber", txtContactNo.Text);
            cmd.Parameters.AddWithValue("@Age", nudAge.Value);
            cmd.Parameters.AddWithValue("@CivilStatus", cboCivilStatus.SelectedItem);
            cmd.Parameters.AddWithValue("@BloodType", txtBloodType.Text);
            cmd.ExecuteNonQuery();

            MessageBox.Show("Updated Successfully");

            loadData();
            loadData();
        }

        private void dgvPatientAccount_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            string gender, age, civilStatus, DOB;

            int cAge;

            int index;
            index = e.RowIndex;
            DataGridViewRow row         = dgvMPA.Rows[index];
            lblPID.Text                 = row.Cells[0].Value.ToString();
            txtLastName.Text            = row.Cells[1].Value.ToString();
            txtFirstName.Text           = row.Cells[2].Value.ToString();
            txtMiddleInitial.Text       = row.Cells[3].Value.ToString();
            DOB                         = row.Cells[4].Value.ToString();
            txtAddress.Text             = row.Cells[5].Value.ToString();
            gender                      = row.Cells[6].Value.ToString();
            txtNationality.Text         = row.Cells[7].Value.ToString();
            txtContactNo.Text           = row.Cells[8].Value.ToString();
            age                         = row.Cells[9].Value.ToString();
            civilStatus                 = row.Cells[10].Value.ToString();
            txtBloodType.Text           = row.Cells[11].Value.ToString();

            //
            if (gender == "Male")
            {
                rbMale.Checked = true;
            }
            else if (gender == "Female")
            {
                rbFemale.Checked = true;
            }
            //
            dtpDOB.Value = Convert.ToDateTime(DOB);
            //
            //
            cAge = Int32.Parse(age);
            nudAge.Value = cAge;
            //
            if (civilStatus == "Single")
            {
                cboCivilStatus.SelectedItem = "Single";
            }
            else if (civilStatus == "Married")
            {
                cboCivilStatus.SelectedItem = "Married";
            }
            else if (civilStatus == "Widowed")
            {
                cboCivilStatus.SelectedItem = "Widowed";
            }

        }
        public void searchData(string valueToSearch)
        {
            string query = "Select * FROM tblpatient WHERE CONCAT (PID) like '%" + valueToSearch + "%'";
            cmd = new MySqlCommand(query, con);
            adapter = new MySqlDataAdapter(cmd);
            tbl = new DataTable();
            adapter.Fill(tbl);
            dgvMPA.DataSource = tbl;
        }

        private void EventSearchKey(object sender, EventArgs e)
        {
            string valueToSearch = txtSearchID.Text.ToString();
            searchData(valueToSearch);
        }

        private void txtNumbersOnly_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsNumber(e.KeyChar) && !char.IsControl(e.KeyChar))
            {
                e.Handled = true;
                string message = "Please Enter Numbers Only";
                string title = "Notice";
                MessageBoxButtons buttons = MessageBoxButtons.OK;
                MessageBoxIcon icon = MessageBoxIcon.Warning;
                MessageBox.Show(message, title, buttons, icon);
            }
        }
    }
}

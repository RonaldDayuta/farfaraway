﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FarFarAway_HealthCenter.UserControls
{
    public partial class ucCA : UserControl
    {
        MySqlDataReader dtr;
        public ucCA()
        {
            InitializeComponent();

            
        }

        private void ucCA_Load(object sender, EventArgs e)
        {

        }

        private void txtTextOnly_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsLetter(e.KeyChar) && !char.IsControl(e.KeyChar)&& e.KeyChar != ' ' && char.IsLetterOrDigit(e.KeyChar))
            { 
                e.Handled = true;
                string message = "Please Enter Letters Only!";
                string title = "Notice";
                MessageBoxButtons buttons = MessageBoxButtons.OK;
                MessageBoxIcon icon = MessageBoxIcon.Warning;
                MessageBox.Show(message, title, buttons, icon);
            }
        }

        private void txtNumbersOnly_KeyPress(object sender, KeyPressEventArgs e)
        {

            if (!char.IsNumber(e.KeyChar) && !char.IsControl(e.KeyChar))
            {
                e.Handled = true;
                string message = "Please Enter Numbers Only";
                string title = "Notice";
                MessageBoxButtons buttons = MessageBoxButtons.OK;
                MessageBoxIcon icon = MessageBoxIcon.Warning;
                MessageBox.Show(message, title, buttons, icon);
            }
        }
        private void btnCreateAcc_Click(object sender, EventArgs e)
        {
            int Na = 0;

            string ca = @"server=localhost; userid=root; password=; database=dbhealth_center";
            var con = new MySqlConnection(ca);
            string gender = "";

            if (rbMale.Checked)
            {
                gender = "Male";
            }
            else if (rbFemale.Checked)
            {
                gender = "Female";
            }

            try
            {
                con.Open();
                string stm = "INSERT INTO tbllogin (LID, LName, FName, MName, Address, Gender, DateOfBirth, Position, Nationality, ContactNumber,Age, CivilStatus, UserName, Password)" +
                    "VALUES (" + Na + ",'"
                    + txtLastName.Text + "','"
                    + txtFirstName.Text + "','"
                    + txtMiddleInitial.Text + "','"
                    + txtAddress.Text               + "','"
                    + gender                        + "','"
                    + this.dtpDOB.Text              + "','"
                    +cboPosition.SelectedItem       +"','"
                    +txtNationality.Text            +"','"
                    +txtContactNo.Text              +"',"
                    +nudAge.Value                   +",'"
                    +cboCivilStatus.SelectedItem    +"','"
                    + txtUsername.Text              + "','"
                    + txtPassword.Text              + "')";


                var cmd = new MySqlCommand(stm, con);
                dtr = cmd.ExecuteReader();

                MessageBox.Show("Successfully Added to database");

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            con.Close();

            txtLastName.Clear();
            txtFirstName.Clear();
            txtMiddleInitial.Clear();
            txtAddress.Clear();
            rbMale.Checked = false;
            rbFemale.Checked = false;
            dtpDOB.Value = new DateTime(1950, 01, 01);
            cboPosition.SelectedIndex = -1;
            txtNationality.Clear();
            txtContactNo.Clear();
            nudAge.Value = 0;
            cboCivilStatus.SelectedIndex = -1;
            txtUsername.Clear();
            txtPassword.Clear();
           
        }

        private void txtTextValidating(object sender, CancelEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtFirstName.Text))
            {
                e.Cancel = true;
                txtFirstName.Focus();
                errorFname.SetError(txtFirstName, "First Name should not be blank");
            }
            else
            {
                e.Cancel = false;
                errorFname.SetError(txtFirstName, "");
            }    
        }
    }

}

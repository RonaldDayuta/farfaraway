﻿using MySql.Data.MySqlClient;
using MySql.Data.MySqlClient.Authentication;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace FarFarAway_HealthCenter.UserControls
{
    public partial class ucCMR : UserControl
    {
        MySqlDataReader dtr;

        public ucCMR()
        {
            InitializeComponent();
        }

        private void ucCR_Load(object sender, EventArgs e)
        {

        }

        private void btnCreateRecord_Click(object sender, EventArgs e)
        {
            int Na = 0;
            int PID = 0;
            PID = Int32.Parse(txtPatientID.Text);
            string ca = @"server=localhost; userid=root; password=; database=dbhealth_center";
            var con = new MySqlConnection(ca);

            try
            {
                con.Open();
                string stm = "INSERT INTO tblmedrecord (MRID, PID, Height, Weight, BloodPressure, PulseRate, SugarLevel, Temperature, Description, Symptoms)" +
                    "VALUES                     ("
                    + Na                        +"," 
                    + PID                       + ",'" 
                    + txtHeight.Text            +"','" 
                    + txtWeight.Text            +"','" 
                    + txtBloodPressure.Text     +"','" 
                    + txtPulseRate.Text         +"','" 
                    + txtSugarLevel.Text        +"','" 
                    + txtTemperature.Text       +"','" 
                    + txtDescription.Text       +"','" 
                    + txtSymptoms.Text          +"')";

                var cmd = new MySqlCommand(stm, con);
                dtr = cmd.ExecuteReader();

                MessageBox.Show("Successfully Added to database");
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        private void txtTextOnly_KeyPress(object sender, KeyPressEventArgs e)
        {

            if (!char.IsLetter(e.KeyChar) && !char.IsControl(e.KeyChar))
            {
                e.Handled = true;
                string message = "Please Enter Letters Only";
                string title = "Notice";
                MessageBoxButtons buttons = MessageBoxButtons.OK;
                MessageBoxIcon icon = MessageBoxIcon.Warning;
                MessageBox.Show(message, title, buttons, icon);
            }
        }

        private void txtNumbersOnly_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsNumber(e.KeyChar) && !char.IsControl(e.KeyChar))
            {
                e.Handled = true;
                string message = "Please Enter Numbers Only";
                string title = "Notice";
                MessageBoxButtons buttons = MessageBoxButtons.OK;
                MessageBoxIcon icon = MessageBoxIcon.Warning;
                MessageBox.Show(message, title, buttons, icon);
            }
        }
    }
}

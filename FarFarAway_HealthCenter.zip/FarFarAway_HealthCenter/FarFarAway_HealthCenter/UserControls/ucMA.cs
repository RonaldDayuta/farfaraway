﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Net.Mime.MediaTypeNames;
using static System.Windows.Forms.AxHost;

namespace FarFarAway_HealthCenter.UserControls
{


    public partial class ucMA : UserControl
    {
        MySqlConnection con = new MySqlConnection("datasource = localhost; userid = root; password = ; database = dbhealth_center; Convert Zero Datetime=True;");
        MySqlCommand cmd = new MySqlCommand();
        MySqlDataReader dtr;
        MySqlDataAdapter adapter;
        DataTable tbl;
        public ucMA()
        {
            InitializeComponent();
        }

        public void loadData()
        {
            try
            {
                con.Open();

                string sql = "SELECT * FROM tbllogin";
                cmd = new MySqlCommand(sql, con);
                dtr = cmd.ExecuteReader();
                DataTable dt = new DataTable();
                dt.Load(dtr);
                dgvMA.DataSource = dt;

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                con.Close();
            }
        }
        private void dgvMA_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

            string gender, position, age, civilStatus,DOB;
            
            int cAge;

            int index;
            index = e.RowIndex;
            DataGridViewRow row = dgvMA.Rows[index];
            lblID.Text              = row.Cells[0].Value.ToString();
            txtLastName.Text        = row.Cells[1].Value.ToString();
            txtFirstName.Text       = row.Cells[2].Value.ToString();
            txtMiddleInitial.Text   = row.Cells[3].Value.ToString();
            txtAddress.Text         = row.Cells[4].Value.ToString();
            gender                  = row.Cells[5].Value.ToString();           
            DOB                     = row.Cells[6].Value.ToString();          
            position                = row.Cells[7].Value.ToString();
            txtNationality.Text     = row.Cells[8].Value.ToString();
            txtContactNo.Text       = row.Cells[9].Value.ToString();
            age                     = row.Cells[10].Value.ToString();          
            civilStatus             = row.Cells[11].Value.ToString();
            txtUsername.Text        = row.Cells[12].Value.ToString();
            txtPassword.Text        = row.Cells[13].Value.ToString();

            //
            if (gender == "Male")
            {
                rbMale.Checked = true;
            }
            else if (gender == "Female")
            {
                rbFemale.Checked = true;
            }
            //
            dtpDOB.Value = Convert.ToDateTime(DOB);
            //
            if (position == "Admin")
            {
                cboPosition.SelectedItem = "Admin";
            }
            else if (position == "Staff")
            {
                cboPosition.SelectedItem = "Staff";
            }
            else if (position == "Assistant")
            {
                cboPosition.SelectedItem = "Assistant";
            }
            //
            cAge = Int32.Parse(age);
            nudAge.Value = cAge;
            //
            if (civilStatus == "Single")
            {
                cboCivilStatus.SelectedItem = "Single";
            }
            else if (civilStatus == "Married")
            {
                cboCivilStatus.SelectedItem = "Married";
            }
            else if (civilStatus == "Widowed")
            {
                cboCivilStatus.SelectedItem = "Widowed";
            }


        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {

            string cgender = "";
            string cposition = "" + cboPosition.SelectedItem;
            int cID = Convert.ToInt32(lblID.Text);

            if (rbMale.Checked)
            {
                cgender = "Male";
            }
            else if (rbFemale.Checked)
            {
                cgender = "Female";
            }

            con.Open();
            MySqlCommand cmd = new MySqlCommand("Update tbllogin set LName =@LName, FName =@FName, MName =@MName, Address =@Address, DateOfBirth =@DateOfBirth, Gender =@Gender, DateOfBirth =@DateOfBirth, Position =@Position, Nationality =@Nationality, ContactNumber =@ContactNumber, Age =@Age, CivilStatus =@CivilStatus, UserName =@UserName, Password =@Password where LID =@LID", con);
            cmd.Parameters.AddWithValue("@LID", int.Parse(lblID.Text));
            cmd.Parameters.AddWithValue("@LName", txtLastName.Text);
            cmd.Parameters.AddWithValue("@FName", txtFirstName.Text);
            cmd.Parameters.AddWithValue("@MName", txtMiddleInitial.Text);
            cmd.Parameters.AddWithValue("@Address", txtAddress.Text);
            cmd.Parameters.AddWithValue("@Gender", cgender);
            cmd.Parameters.AddWithValue("@DateOfBirth", this.dtpDOB.Text);
            //cmd.Parameters.AddWithValue("@DateOfBirth", dtpDOB.Value.ToString("yyyyMMdd"));
            cmd.Parameters.AddWithValue("@Position", cposition);
            cmd.Parameters.AddWithValue("@Nationality", txtNationality.Text);
            cmd.Parameters.AddWithValue("@ContactNumber", txtContactNo.Text);
            cmd.Parameters.AddWithValue("@Age", nudAge.Value);
            cmd.Parameters.AddWithValue("@CivilStatus", cboCivilStatus.SelectedItem);
            cmd.Parameters.AddWithValue("@UserName", txtUsername.Text);
            cmd.Parameters.AddWithValue("@Password", txtPassword.Text);
            cmd.ExecuteNonQuery();

            MessageBox.Show("Updated Successfully");

            loadData();
            loadData();
        }

        private void ucMA_Load(object sender, EventArgs e)
        {
            loadData();
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            loadData();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            int ID = Int32.Parse(lblID.Text);
            con.Open();
            MySqlCommand cmd = new MySqlCommand("Delete from tbllogin where LID =@LID", con);
            cmd.Parameters.AddWithValue("@LID", ID);
            cmd.ExecuteNonQuery();
            con.Close  ();

            txtLastName.Clear();
            txtFirstName.Clear();
            txtMiddleInitial.Clear();
            txtAddress.Clear();
            rbMale.Checked = false;
            rbFemale.Checked = false;
            dtpDOB.Value = new DateTime(1950, 01, 01);
            cboPosition.Text = " ";
            txtNationality.Clear();
            txtContactNo.Clear();
            nudAge.Value = 0;
            cboCivilStatus.Text = " ";
            txtUsername.Clear();
            txtPassword.Clear();
            lblID.ResetText();

            MessageBox.Show("Deleted Successfully");

            loadData();
            loadData();
        }
        
        public void searchData(string valueToSearch)
        {
            string query = "Select * FROM tbllogin WHERE CONCAT (LID) like '%" + valueToSearch + "%'";
            cmd = new MySqlCommand(query, con);
            adapter = new MySqlDataAdapter(cmd);
            tbl = new DataTable();
            adapter.Fill(tbl);
            dgvMA.DataSource = tbl;
        }

        private void EventSearchKey(object sender, EventArgs e)
        {
            string valueToSearch = txtSearchID.Text.ToString();
            searchData(valueToSearch);
        }
    }
}


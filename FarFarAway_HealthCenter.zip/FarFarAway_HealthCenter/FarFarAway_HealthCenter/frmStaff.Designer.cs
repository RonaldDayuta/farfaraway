﻿namespace FarFarAway_HealthCenter
{
    partial class frmStaff
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmStaff));
            this.pnlMain = new System.Windows.Forms.Panel();
            this.ucCPA1 = new FarFarAway_HealthCenter.UserControls.ucCPA();
            this.ucMPA1 = new FarFarAway_HealthCenter.UserControls.ucMPA();
            this.ucMR1 = new FarFarAway_HealthCenter.UserControls.ucMR();
            this.panel3 = new System.Windows.Forms.Panel();
            this.btnLogout = new System.Windows.Forms.Button();
            this.btnMR = new System.Windows.Forms.Button();
            this.btnCPA = new System.Windows.Forms.Button();
            this.btnMPA = new System.Windows.Forms.Button();
            this.pnlMain.SuspendLayout();
            this.panel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlMain
            // 
            this.pnlMain.Controls.Add(this.ucCPA1);
            this.pnlMain.Controls.Add(this.ucMPA1);
            this.pnlMain.Controls.Add(this.ucMR1);
            this.pnlMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlMain.Location = new System.Drawing.Point(277, 0);
            this.pnlMain.Name = "pnlMain";
            this.pnlMain.Size = new System.Drawing.Size(1089, 728);
            this.pnlMain.TabIndex = 3;
            // 
            // ucCPA1
            // 
            this.ucCPA1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ucCPA1.Location = new System.Drawing.Point(0, 0);
            this.ucCPA1.Name = "ucCPA1";
            this.ucCPA1.Size = new System.Drawing.Size(1089, 728);
            this.ucCPA1.TabIndex = 2;
            // 
            // ucMPA1
            // 
            this.ucMPA1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ucMPA1.Location = new System.Drawing.Point(0, 0);
            this.ucMPA1.Name = "ucMPA1";
            this.ucMPA1.Size = new System.Drawing.Size(1089, 728);
            this.ucMPA1.TabIndex = 1;
            // 
            // ucMR1
            // 
            this.ucMR1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ucMR1.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ucMR1.Location = new System.Drawing.Point(0, 0);
            this.ucMR1.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.ucMR1.Name = "ucMR1";
            this.ucMR1.Size = new System.Drawing.Size(1089, 728);
            this.ucMR1.TabIndex = 0;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.Transparent;
            this.panel3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel3.BackgroundImage")));
            this.panel3.Controls.Add(this.btnLogout);
            this.panel3.Controls.Add(this.btnMR);
            this.panel3.Controls.Add(this.btnCPA);
            this.panel3.Controls.Add(this.btnMPA);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel3.Location = new System.Drawing.Point(0, 0);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(277, 728);
            this.panel3.TabIndex = 4;
            // 
            // btnLogout
            // 
            this.btnLogout.BackColor = System.Drawing.Color.Gray;
            this.btnLogout.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnLogout.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.btnLogout.FlatAppearance.BorderSize = 0;
            this.btnLogout.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnLogout.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLogout.ForeColor = System.Drawing.Color.Transparent;
            this.btnLogout.Location = new System.Drawing.Point(0, 681);
            this.btnLogout.Name = "btnLogout";
            this.btnLogout.Size = new System.Drawing.Size(277, 47);
            this.btnLogout.TabIndex = 10;
            this.btnLogout.Text = "Logout";
            this.btnLogout.UseVisualStyleBackColor = false;
            this.btnLogout.Click += new System.EventHandler(this.btnLogout_Click);
            this.btnLogout.MouseEnter += new System.EventHandler(this.btnLogout_MouseEnter);
            this.btnLogout.MouseLeave += new System.EventHandler(this.btnLogout_MouseLeave);
            // 
            // btnMR
            // 
            this.btnMR.BackColor = System.Drawing.Color.Gray;
            this.btnMR.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnMR.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.btnMR.FlatAppearance.BorderSize = 0;
            this.btnMR.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnMR.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMR.ForeColor = System.Drawing.Color.Transparent;
            this.btnMR.Location = new System.Drawing.Point(0, 333);
            this.btnMR.Name = "btnMR";
            this.btnMR.Size = new System.Drawing.Size(277, 47);
            this.btnMR.TabIndex = 8;
            this.btnMR.Text = "Medical Records";
            this.btnMR.UseVisualStyleBackColor = false;
            this.btnMR.Click += new System.EventHandler(this.btnMR_Click);
            this.btnMR.MouseEnter += new System.EventHandler(this.btnMR_MouseEnter);
            this.btnMR.MouseLeave += new System.EventHandler(this.btnMR_MouseLeave);
            // 
            // btnCPA
            // 
            this.btnCPA.BackColor = System.Drawing.Color.Gray;
            this.btnCPA.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnCPA.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.btnCPA.FlatAppearance.BorderSize = 0;
            this.btnCPA.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCPA.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCPA.ForeColor = System.Drawing.Color.White;
            this.btnCPA.Location = new System.Drawing.Point(0, 439);
            this.btnCPA.Name = "btnCPA";
            this.btnCPA.Size = new System.Drawing.Size(277, 47);
            this.btnCPA.TabIndex = 7;
            this.btnCPA.Text = "Create Patient Account";
            this.btnCPA.UseVisualStyleBackColor = false;
            this.btnCPA.Click += new System.EventHandler(this.btnCPA_Click);
            this.btnCPA.MouseEnter += new System.EventHandler(this.btnCPA_MouseEnter);
            this.btnCPA.MouseLeave += new System.EventHandler(this.btnCPA_MouseLeave);
            // 
            // btnMPA
            // 
            this.btnMPA.BackColor = System.Drawing.Color.Gray;
            this.btnMPA.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnMPA.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.btnMPA.FlatAppearance.BorderSize = 0;
            this.btnMPA.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnMPA.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMPA.ForeColor = System.Drawing.Color.Transparent;
            this.btnMPA.Location = new System.Drawing.Point(0, 386);
            this.btnMPA.Name = "btnMPA";
            this.btnMPA.Size = new System.Drawing.Size(277, 47);
            this.btnMPA.TabIndex = 6;
            this.btnMPA.Text = "Manage Patients Accounts";
            this.btnMPA.UseVisualStyleBackColor = false;
            this.btnMPA.Click += new System.EventHandler(this.btnMPA_Click);
            this.btnMPA.MouseEnter += new System.EventHandler(this.btnMPA_MouseEnter);
            this.btnMPA.MouseLeave += new System.EventHandler(this.btnMPA_MouseLeave);
            // 
            // frmStaff
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1366, 728);
            this.Controls.Add(this.pnlMain);
            this.Controls.Add(this.panel3);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "frmStaff";
            this.Text = "frmStaff";
            this.pnlMain.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Panel pnlMain;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Button btnLogout;
        private System.Windows.Forms.Button btnMR;
        private System.Windows.Forms.Button btnCPA;
        private System.Windows.Forms.Button btnMPA;
        private UserControls.ucCPA ucCPA1;
        private UserControls.ucMPA ucMPA1;
        private UserControls.ucMR ucMR1;
    }
}
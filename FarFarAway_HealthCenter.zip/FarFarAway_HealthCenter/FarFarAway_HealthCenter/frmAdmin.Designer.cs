﻿namespace FarFarAway_HealthCenter
{
    partial class frmAdmin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmAdmin));
            this.panel3 = new System.Windows.Forms.Panel();
            this.btnLogout = new System.Windows.Forms.Button();
            this.btnCA = new System.Windows.Forms.Button();
            this.btnMA = new System.Windows.Forms.Button();
            this.pnlMain = new System.Windows.Forms.Panel();
            this.ucCA = new FarFarAway_HealthCenter.UserControls.ucCA();
            this.ucMA = new FarFarAway_HealthCenter.UserControls.ucMA();
            this.panel3.SuspendLayout();
            this.pnlMain.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.Transparent;
            this.panel3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel3.BackgroundImage")));
            this.panel3.Controls.Add(this.btnLogout);
            this.panel3.Controls.Add(this.btnCA);
            this.panel3.Controls.Add(this.btnMA);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel3.Location = new System.Drawing.Point(0, 0);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(277, 728);
            this.panel3.TabIndex = 2;
            // 
            // btnLogout
            // 
            this.btnLogout.BackColor = System.Drawing.Color.Gray;
            this.btnLogout.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnLogout.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.btnLogout.FlatAppearance.BorderSize = 0;
            this.btnLogout.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnLogout.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLogout.ForeColor = System.Drawing.Color.Transparent;
            this.btnLogout.Location = new System.Drawing.Point(0, 681);
            this.btnLogout.Name = "btnLogout";
            this.btnLogout.Size = new System.Drawing.Size(277, 47);
            this.btnLogout.TabIndex = 10;
            this.btnLogout.Text = "Logout";
            this.btnLogout.UseVisualStyleBackColor = false;
            this.btnLogout.Click += new System.EventHandler(this.btnLogout_Click);
            this.btnLogout.MouseEnter += new System.EventHandler(this.btnLogoutChangeColorA);
            this.btnLogout.MouseLeave += new System.EventHandler(this.btnLogoutChangeColorB);
            // 
            // btnCA
            // 
            this.btnCA.BackColor = System.Drawing.Color.Gray;
            this.btnCA.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnCA.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.btnCA.FlatAppearance.BorderSize = 0;
            this.btnCA.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCA.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCA.ForeColor = System.Drawing.Color.White;
            this.btnCA.Location = new System.Drawing.Point(0, 386);
            this.btnCA.Name = "btnCA";
            this.btnCA.Size = new System.Drawing.Size(277, 47);
            this.btnCA.TabIndex = 7;
            this.btnCA.Text = "Create Account";
            this.btnCA.UseVisualStyleBackColor = false;
            this.btnCA.Click += new System.EventHandler(this.btnCA_Click);
            this.btnCA.MouseEnter += new System.EventHandler(this.btnCAChangeColorA);
            this.btnCA.MouseLeave += new System.EventHandler(this.btnCAChangeColorB);
            // 
            // btnMA
            // 
            this.btnMA.BackColor = System.Drawing.Color.Gray;
            this.btnMA.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnMA.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.btnMA.FlatAppearance.BorderSize = 0;
            this.btnMA.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnMA.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMA.ForeColor = System.Drawing.Color.Transparent;
            this.btnMA.Location = new System.Drawing.Point(0, 333);
            this.btnMA.Name = "btnMA";
            this.btnMA.Size = new System.Drawing.Size(277, 47);
            this.btnMA.TabIndex = 6;
            this.btnMA.Text = "Manage Accounts";
            this.btnMA.UseVisualStyleBackColor = false;
            this.btnMA.Click += new System.EventHandler(this.btnMA_Click);
            this.btnMA.MouseEnter += new System.EventHandler(this.btnMAChangeColorA);
            this.btnMA.MouseLeave += new System.EventHandler(this.btnMAChangeColorB);
            // 
            // pnlMain
            // 
            this.pnlMain.BackColor = System.Drawing.Color.Transparent;
            this.pnlMain.Controls.Add(this.ucCA);
            this.pnlMain.Controls.Add(this.ucMA);
            this.pnlMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlMain.Location = new System.Drawing.Point(277, 0);
            this.pnlMain.Name = "pnlMain";
            this.pnlMain.Size = new System.Drawing.Size(1089, 728);
            this.pnlMain.TabIndex = 3;
            // 
            // ucCA
            // 
            this.ucCA.BackColor = System.Drawing.Color.Transparent;
            this.ucCA.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ucCA.Location = new System.Drawing.Point(0, 0);
            this.ucCA.Name = "ucCA";
            this.ucCA.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.ucCA.Size = new System.Drawing.Size(1089, 728);
            this.ucCA.TabIndex = 10;
            // 
            // ucMA
            // 
            this.ucMA.BackColor = System.Drawing.Color.Transparent;
            this.ucMA.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ucMA.Location = new System.Drawing.Point(0, 0);
            this.ucMA.Name = "ucMA";
            this.ucMA.Size = new System.Drawing.Size(1089, 728);
            this.ucMA.TabIndex = 0;
            // 
            // frmAdmin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1366, 728);
            this.Controls.Add(this.pnlMain);
            this.Controls.Add(this.panel3);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "frmAdmin";
            this.Text = "Form1";
            this.panel3.ResumeLayout(false);
            this.pnlMain.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Button btnCA;
        private System.Windows.Forms.Button btnMA;
        private System.Windows.Forms.Panel pnlMain;
        private UserControls.ucCA ucCA;
        private UserControls.ucMA ucMA;
        private System.Windows.Forms.Button btnLogout;
    }
}
﻿namespace FarFarAway_HealthCenter
{
    partial class frmAssistant
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmAssistant));
            this.pnlMain = new System.Windows.Forms.Panel();
            this.ucCMR1 = new FarFarAway_HealthCenter.UserControls.ucCMR();
            this.ucMMR1 = new FarFarAway_HealthCenter.UserControls.ucMMR();
            this.panel3 = new System.Windows.Forms.Panel();
            this.btnLogout = new System.Windows.Forms.Button();
            this.btnMMR = new System.Windows.Forms.Button();
            this.btnCMA = new System.Windows.Forms.Button();
            this.pnlMain.SuspendLayout();
            this.panel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlMain
            // 
            this.pnlMain.Controls.Add(this.ucCMR1);
            this.pnlMain.Controls.Add(this.ucMMR1);
            this.pnlMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlMain.Location = new System.Drawing.Point(277, 0);
            this.pnlMain.Name = "pnlMain";
            this.pnlMain.Size = new System.Drawing.Size(1089, 728);
            this.pnlMain.TabIndex = 5;
            // 
            // ucCMR1
            // 
            this.ucCMR1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ucCMR1.Location = new System.Drawing.Point(0, 0);
            this.ucCMR1.Name = "ucCMR1";
            this.ucCMR1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.ucCMR1.Size = new System.Drawing.Size(1089, 728);
            this.ucCMR1.TabIndex = 11;
            // 
            // ucMMR1
            // 
            this.ucMMR1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ucMMR1.Location = new System.Drawing.Point(0, 0);
            this.ucMMR1.Name = "ucMMR1";
            this.ucMMR1.Size = new System.Drawing.Size(1089, 728);
            this.ucMMR1.TabIndex = 0;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.Transparent;
            this.panel3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel3.BackgroundImage")));
            this.panel3.Controls.Add(this.btnLogout);
            this.panel3.Controls.Add(this.btnMMR);
            this.panel3.Controls.Add(this.btnCMA);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel3.Location = new System.Drawing.Point(0, 0);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(277, 728);
            this.panel3.TabIndex = 6;
            // 
            // btnLogout
            // 
            this.btnLogout.BackColor = System.Drawing.Color.DimGray;
            this.btnLogout.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnLogout.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.btnLogout.FlatAppearance.BorderSize = 0;
            this.btnLogout.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnLogout.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLogout.ForeColor = System.Drawing.Color.Transparent;
            this.btnLogout.Location = new System.Drawing.Point(0, 681);
            this.btnLogout.Name = "btnLogout";
            this.btnLogout.Size = new System.Drawing.Size(277, 47);
            this.btnLogout.TabIndex = 10;
            this.btnLogout.Text = "Logout";
            this.btnLogout.UseVisualStyleBackColor = false;
            this.btnLogout.Click += new System.EventHandler(this.btnLogout_Click);
            this.btnLogout.MouseEnter += new System.EventHandler(this.btnLogout_MouseEnter);
            this.btnLogout.MouseLeave += new System.EventHandler(this.btnLogout_MouseLeave);
            // 
            // btnMMR
            // 
            this.btnMMR.BackColor = System.Drawing.Color.Gray;
            this.btnMMR.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnMMR.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.btnMMR.FlatAppearance.BorderSize = 0;
            this.btnMMR.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnMMR.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMMR.ForeColor = System.Drawing.Color.Transparent;
            this.btnMMR.Location = new System.Drawing.Point(0, 333);
            this.btnMMR.Name = "btnMMR";
            this.btnMMR.Size = new System.Drawing.Size(277, 47);
            this.btnMMR.TabIndex = 8;
            this.btnMMR.Text = "Manage Medical Records";
            this.btnMMR.UseVisualStyleBackColor = false;
            this.btnMMR.Click += new System.EventHandler(this.btnMMR_Click);
            this.btnMMR.MouseEnter += new System.EventHandler(this.btnMMR_MouseEnter);
            this.btnMMR.MouseLeave += new System.EventHandler(this.btnMMR_MouseLeave);
            // 
            // btnCMA
            // 
            this.btnCMA.BackColor = System.Drawing.Color.Gray;
            this.btnCMA.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnCMA.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.btnCMA.FlatAppearance.BorderSize = 0;
            this.btnCMA.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCMA.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCMA.ForeColor = System.Drawing.Color.Transparent;
            this.btnCMA.Location = new System.Drawing.Point(0, 386);
            this.btnCMA.Name = "btnCMA";
            this.btnCMA.Size = new System.Drawing.Size(277, 47);
            this.btnCMA.TabIndex = 6;
            this.btnCMA.Text = "Create Medical Record";
            this.btnCMA.UseVisualStyleBackColor = false;
            this.btnCMA.Click += new System.EventHandler(this.btnCMA_Click);
            this.btnCMA.MouseEnter += new System.EventHandler(this.btnCMA_MouseEnter);
            this.btnCMA.MouseLeave += new System.EventHandler(this.btnCMA_MouseLeave);
            // 
            // frmAssistant
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1366, 728);
            this.Controls.Add(this.pnlMain);
            this.Controls.Add(this.panel3);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "frmAssistant";
            this.Text = "frmAssistant";
            this.pnlMain.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlMain;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Button btnLogout;
        private System.Windows.Forms.Button btnMMR;
        private System.Windows.Forms.Button btnCMA;
        private UserControls.ucMMR ucMMR1;
        private UserControls.ucCMR ucCMR1;
    }
}